/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package nombre.edad;

import java.util.Scanner;

/**
 *
 * @author Usuario
 */
public class NombreEdad {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String nombre;
        System.out.println("ingrese su nombre: ");
        nombre = input.nextLine();
        int edad;
        System.out.println("ingrese su edad: ");
        edad = input.nextInt();
        System.out.println("El nombre es " + nombre + " y la edad es " + edad + " años");
        
        // TODO code application logic here
    }
    
}

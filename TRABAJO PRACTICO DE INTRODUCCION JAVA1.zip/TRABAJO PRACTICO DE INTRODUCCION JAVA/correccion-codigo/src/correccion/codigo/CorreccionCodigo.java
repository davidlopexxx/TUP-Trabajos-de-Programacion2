/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package correccion.codigo;

import java.util.Scanner;

/**
 *
 * @author Usuario
 */
public class CorreccionCodigo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Ingresa tu nombre: ");
        
        //coreccion de error encontrado en el codigo,  String nombre = scanner.nextInt(); // ERROR 
        String nombre = input.nextLine(); // se modifica scanner.nextInt() por input.nextLine()
        System.out.println("Hola, " + nombre);
        
        // TODO code application logic here
    }
    
}

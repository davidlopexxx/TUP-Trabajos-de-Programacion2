/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package operaciones.aritmeticas;

import java.util.Scanner;

/**
 *
 * @author Usuario
 */
public class OperacionesAritmeticas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int numero1;
        System.out.print("ingrese su numero1: ");
        numero1 = input.nextInt();
        int numero2;
        System.out.print("ingrese su numero2: ");
        numero2 = input.nextInt();
        
        //operaciones
        int suma = numero1 + numero2;
        int resta = numero1 - numero2;
        int multiplicacion= numero1 * numero2;
        int divicion = numero1 / numero2;
        
        System.out.println("La suma es: " + suma + " La resta es: " + resta);
        System.out.println("La multiplicacion es: " + multiplicacion + " La divicion es: " + divicion);
        // TODO code application logic here
    }
    
}

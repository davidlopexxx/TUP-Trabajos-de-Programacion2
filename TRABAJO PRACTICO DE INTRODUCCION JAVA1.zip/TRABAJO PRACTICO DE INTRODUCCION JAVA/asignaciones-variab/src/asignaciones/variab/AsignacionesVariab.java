/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package asignaciones.variab;

/**
 *
 * @author Usuario
 */
public class AsignacionesVariab {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String nombre;
        nombre = "ANGEL";
        int edad;
        edad = 34;
        double altura;
        altura = 1.89;
        boolean estudiante;
        estudiante = true;
        
        System.out.println("tu nombre es " + nombre);
        System.out.println("tu edad es " + edad);
        System.out.println("tu altura es " + altura);
        System.out.println("estudiante " + estudiante);
        // TODO code application logic here
    }
    
}

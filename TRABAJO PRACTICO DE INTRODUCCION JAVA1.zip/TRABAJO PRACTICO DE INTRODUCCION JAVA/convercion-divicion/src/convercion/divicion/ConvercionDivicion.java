/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package convercion.divicion;

import java.util.Scanner;

/**
 *
 * @author Usuario
 */
public class ConvercionDivicion {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int numero1;
        System.out.print("ingrese su numero1: ");
        numero1 = input.nextInt();
        int numero2;
        System.out.print("ingrese su numero2: ");
        numero2 = input.nextInt();
        
        //divicion en int
        int div_entero;
        div_entero = numero1 / numero2;
        System.out.println("El resultado en entero es: " + div_entero);
        
        //convercion a double
        double div_decim;
        div_decim = ((double) numero1  / numero2) ;
        System.out.println("El resultado en decimal es: " + div_decim);
        // TODO code application logic here
    }
    
}

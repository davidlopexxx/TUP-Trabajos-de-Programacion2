/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package caracter.escape;

/**
 *
 * @author Usuario
 */
public class CaracterEscape {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String nombre;
        nombre =  "Juan Perez";
        int edad;
        edad = 30;
        String direccion;
        direccion = "calle falsa 123";
        
         System.out.println("Nombre: "+ nombre + "\tEdad: " + edad + "\tDireccion: " + direccion);
         System.out.println("Nombre: "+ nombre + "\nEdad: " + edad + "\nDireccion: " + direccion);
        // TODO code application logic here
    }
    
}
